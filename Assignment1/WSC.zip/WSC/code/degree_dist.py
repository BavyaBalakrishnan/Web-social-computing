import matplotlib.pyplot as plt
import networkx as nx
G=nx.read_edgelist('p2p-Gnutella06,txt')
def plot_deg_dist(G):
	all_dregrees=dict(nx.degree(G)).values()
	unique_degrees=list(set(all_dregrees))
	#print unique_degrees
	count_of_degrees=[]

	for i in unique_degrees:
		x=list(all_dregrees).count(i)
		count_of_degrees.append(x)

	#plt.plot(unique_degrees,count_of_degrees,'yo')
	plt.loglog(unique_degrees,count_of_degrees,'yo')
	plt.xlabel('Degree')
	plt.ylabel('No of Nodes')
	plt.title('Log-log Degree Distribution of Gnutella peer-to-peer network')
	plt.show()	


plot_deg_dist(G)
