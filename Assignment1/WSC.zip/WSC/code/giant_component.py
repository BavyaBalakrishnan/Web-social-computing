import matplotlib.pyplot as plt
import networkx as nx
G=nx.read_edgelist('Data_sets/twitter_combined.txt')
connected=nx.is_connected(G)
if connected :
  
  Gcc = sorted(nx.connected_components(G), key=len, reverse=True)
  G0 = G.subgraph(Gcc[0])
  nx.draw_networkx_edges(G0, pos=nx.spring_layout(G),
                           with_labels=False,
                           edge_color='r',
                           width=6.0
                          )
plt.show()
