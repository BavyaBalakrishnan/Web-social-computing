import matplotlib.pyplot as plt
import networkx as nx
G=nx.read_edgelist('ca-HepTh.txt')
nx.draw(G)
#nx.draw_circular(G)
plt.show()
