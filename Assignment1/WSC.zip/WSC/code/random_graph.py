import matplotlib.pyplot as plt
import networkx as nx
import numpy as np

def plot_deg_dist(G):
	all_degree=dict(nx.degree(G)).values()
	
	unique_degree=list(set(all_degree))
	
	count_degree=[]
	all_degree=list(all_degree)
	
	for i in unique_degree:
		x=all_degree.count(i)
		count_degree.append(x)
	
	
	
	plt.plot(unique_degree,count_degree,'yo-')
	plt.xlabel('Degrees')
	plt.ylabel('No of nodes ')
	plt.title('Degree distribution of network')
	plt.show()

Grand = nx.gnm_random_graph(8717, 31525)
print("Shortest path ")
for C in (Grand.subgraph(c).copy() for c in nx.connected_components(Grand)):
	print(nx.average_shortest_path_length(C))
print ('Average clustering coefficient : ',nx.average_clustering(Grand))
Gcc = sorted(nx.connected_components(G), key=len, reverse=True)
g = G.subgraph(Gcc[0])
print('Diameter of largest connected component: ', nx.diameter(g)) 
print('average shortest paths of largest connected component : ',nx.average_shortest_path_length(g))
plot_deg_dist(Grand)
