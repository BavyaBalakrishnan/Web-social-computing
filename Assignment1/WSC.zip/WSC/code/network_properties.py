import matplotlib.pyplot as plt
import networkx as nx
G=nx.read_edgelist('Data_sets/email-Enron.txt')
print (nx.info(G))
directed=nx.is_directed(G)
print ('Is graph directed:',directed)
print ('Density : ',nx.density(G))
connected=nx.is_connected(G)
#print(nx.clustering(G))
print ('Average clustering coefficient : ',nx.average_clustering(G))
print ('Number of connected components : ',nx.number_connected_components(G))
print ('Is graph connected : ',connected)

# returns number of different connected components 
# returns number of nodes to be removed 
# so that Graph becomes disconnected 
if connected :
  print('Diameter: ', nx.diameter(G)) 
  print ('k value in k-connectedness : ',nx.node_connectivity(G))
  print ('average of shortest paths : ',nx.average_shortest_path_length(G))
# identify largest connected component
  
else :
 
  #for c in nx.connected_components(G): 
   
  Gcc = sorted(nx.connected_components(G), key=len, reverse=True)
  g = G.subgraph(Gcc[0])
  print('k value in k-connectedness of giant component : ',nx.node_connectivity(g))
  print('Diameter of giant component : ',nx.diameter(g))
  print('average of shortest paths of giant component : ',nx.average_shortest_path_length(g))
  
# returns list of nodes in different connected components 
#print 'list of nodes in diff connected components : ',list(nx.connected_components(G))
  

#for directed graphs
if directed:
	print ('Is graph strongly connected : ',nx.is_strongly_connected(G))
	print ('Number of strongly connected components : ',nx.number_strongly_connected_components(G))
  # returns list of nodes in different strongly connected components 
	#print 'list of nodes in diff strongly connected components : ',list(nx.strongly_connected_components(G))

# returns average of shortest paths between all possible pairs of nodes
#print 'Shortest path : ',int(nx.shortest_path_length(G,source=339,target=260))


