import networkx as nx 
import matplotlib.pyplot as plt 
from operator import itemgetter

import networkx as nx

#Returns HITS hubs and authorities values for nodes.
def hits(G, max_iteration=100, tolerance=1.0e-8, start_value=None, normalization=True):
    """

    Parameters
    ----------
    G : graph
      A NetworkX graph

    max_iteration : integer, optional
      Maximum number of iterations in power method.

    tolerance : float, optional
      Error tolerance used to check convergence in power method iteration.

    start_value : dictionary, optional
      Starting value of each node for power method iteration.

    normalization : bool (default=True)
       Normalize results by the sum of all of the values.

    Returns
    -------
    (hubs,authorities) : two-tuple of dictionaries
       Two dictionaries keyed by node containing the hub and authority
       values.

    Raises
    ------
    PowerIterationFailedConvergence
        If the algorithm fails to converge to the specified tolerance
        within the specified number of iterations of the power iteration
        method.

    
      """
    if type(G) == nx.MultiGraph or type(G) == nx.MultiDiGraph:
        raise Exception("hits not defined for graphs with multiedges(multigraphs).")
    if len(G) == 0:
        return {}, {}
    # if start_value not given choose default starting vector 
    if start_value is None:
        hub = dict.fromkeys(G, 1.0 / G.number_of_nodes())
    else:
        hub = start_value
        # normalize starting vector
        s = 1.0 / sum(hub.values())
        for k in hub:
            hub[k] *= s
    for _ in range(max_iteration):  # power iteration: maximum upto max_iteration iterations
        hlast = hub
        hub = dict.fromkeys(hlast.keys(), 0)
        authority = dict.fromkeys(hlast.keys(), 0)
       
        for n in hub:
            for nbr in G[n]:
                authority[nbr] += hlast[n] * G[n][nbr].get('weight', 1)
        # now multiply hub=Ga
        for n in hub:
            for nbr in G[n]:
                hub[n] += authority[nbr] * G[n][nbr].get('weight', 1)
        # normalize vector
        s = 1.0 / max(hub.values())
        for n in hub:
            hub[n] *= s
        # normalize vector
        s = 1.0 / max(authority.values())
        for n in authority:
            authority[n] *= s
        # check for convergence, l1 norm
        err = sum([abs(hub[n] - hlast[n]) for n in hub])
        if err < tolerance:
            break
    else:
        raise nx.PowerIterationFailedConvergence(max_iteration)
    if normalization:
        s = 1.0 / sum(authority.values())
        for n in authority:
            authority[n] *= s
        s = 1.0 / sum(hub.values())
        for n in hub:
            hub[n] *= s
    return hub, authority



  
def hits_function(G,maximum_iter):
	if not G.is_directed(): 
		G = G.to_directed() 
	# The in-built hits function returns two dictionaries keyed by nodes 
	# containing hub scores and authority scores respectively. 
 	#return nx.hits(G, max_iter = maximum_iter, normalized = True) 
	return hits(G, max_iteration = maximum_iter, normalization = True) 



def rankdetails(score):
	#Nodes having the highest and lowest PageRank
	all_values=score.values()
	min_value=min(all_values)
	min_key=min(score,key=score.get)
	max_value=max(all_values)
	max_key=max(score,key=score.get)
	print("HITS: Maximum value :",max_value)
	print("HITS: Node with Maximum value :",max_key)
	print("HITS: Minimum value :",min_value)
	print("HITS: Node with Minimum value :",min_key)
	res = dict(sorted(score.items(), key = itemgetter(1), reverse = True)[:10]) 
	# printing result 
	print("The top 10 Node ,score pairs are  " + str(res)) 
	res = dict(sorted(score.items(), key = itemgetter(1), reverse = False)[:10]) 
	# printing result 
	print("The Bottom 10 Node ,score pairs are  " + str(res)) 



def plot_scores(hubs_core,authorities_score):
	all_hubscore=hubs_core.values()
	unique_hubscore=list(set(all_hubscore))
	#print unique_degrees
	count_of_hubscore=[]
	for i in unique_hubscore:
		x=list(all_hubscore).count(i)
		count_of_hubscore.append(x)

	all_authority=authorities_score.values()
	unique_authority=list(set(all_authority))
	#print unique_degrees
	count_of_authority=[]
	for i in unique_authority:
		x=list(all_authority).count(i)
		count_of_authority.append(x)

	#fig, axs = plt.subplots(2)
	#fig.suptitle('S')
	plt.subplot(2, 1, 1)
	plt.plot(unique_hubscore,count_of_hubscore,'yo')
	plt.xlabel('Hubscore')
	plt.ylabel('No of Nodes')
	plt.title('Hub score Distribution of Twitter network')
	plt.tight_layout()

	plt.subplot(2, 1, 2)
	plt.plot(unique_authority,count_of_authority,'yo')
	plt.xlabel('Authority score')
	plt.ylabel('No of Nodes')
	plt.title('Authority score Distribution of Twitter network')
	plt.tight_layout()
	plt.show()


#G=nx.barabasi_albert_graph(60,41) 
print("Facebook")
G=nx.read_edgelist('Data_sets/facebook_combined.txt')
hub_score, authorities_score =hits_function(G,50)  
#print("Hub Scores: ", hub_score) 
#print("Authority Scores: ", authorities_score) 
#plot_scores(hub_score,authorities_score)
rankdetails(hub_score)
rankdetails(authorities_score)

print("Arxiv")
G=nx.read_edgelist('Data_sets/ca-HepTh.txt')
hub_score, authorities_score =hits_function(G,50)
#print("Hub Scores: ", hub_score) 
#print("Authority Scores: ", authorities_score) 
#plot_scores(hub_score,authorities_score)
rankdetails(hub_score)
rankdetails(authorities_score)

print("Gnutella")
G=nx.read_edgelist('Data_sets/p2p-Gnutella06.txt')
hub_score, authorities_score =hits_function(G,70)
#print("Hub Scores: ", hub_score) 
#print("Authority Scores: ", authorities_score) 
#plot_scores(hub_score,authorities_score)
rankdetails(hub_score)
rankdetails(authorities_score) 

print("Twitter")
G=nx.read_edgelist('Data_sets/twitter_combined.txt')
hub_score, authorities_score =hits_function(G,200)
#print("Hub Scores: ", hub_score) 
#print("Authority Scores: ", authorities_score) 
plot_scores(hub_score,authorities_score)
rankdetails(hub_score)
rankdetails(authorities_score) 



