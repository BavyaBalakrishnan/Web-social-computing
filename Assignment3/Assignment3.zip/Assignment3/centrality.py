import networkx as nx
import matplotlib.pyplot as plt
from operator import itemgetter

def centrality(G):
	#Degree centrality
	DC=nx.degree_centrality(G)
	all_values=DC.values()
	max_value=max(all_values)
	max_key=max(DC,key=DC.get)
	print("Degree centrality: Maximum value :",max_value)
	print("Degree centrality: Node with Maximum value :",max_key)
	res = dict(sorted(DC.items(), key = itemgetter(1), reverse = True)[:10]) 
  	# printing result 
	print("The top 10 Node centrality pairs are  " + str(res)) 

	#print(DC)

	#eigenvector centrality 
	EC=nx.eigenvector_centrality(G)
	all_values=EC.values()
	max_value=max(all_values)
	max_key=max(EC,key=EC.get)
	print("Eigenvector centrality: Maximum value :",max_value)
	print("Eigenvector centrality: Node with Maximum value :",max_key)
	res = dict(sorted(EC.items(), key = itemgetter(1), reverse = True)[:10]) 
  	# printing result 
	print("The top 10 Node centrality pairs are  " + str(res)) 
	#print(EC)

	#closeness centrality 
	CC=nx.closeness_centrality(G)
	all_values=CC.values()
	max_value=max(all_values)
	max_key=max(CC,key=CC.get)
	print("Closeness centrality: Maximum value :",max_value)
	print("Closeness centrality: Node with Maximum value :",max_key)
	res = dict(sorted(CC.items(), key = itemgetter(1), reverse = True)[:10]) 
  	# printing result 
	print("The top 10 Node centrality pairs are  " + str(res)) 
	#print(CC) """

	#betweenness centrality
	BC=nx.betweenness_centrality(G)
	all_values=BC.values()
	max_value=max(all_values)
	max_key=max(BC,key=BC.get)
	print("Betweenness centrality: Maximum value :",max_value)
	print("Betweenness centrality: Node with Maximum value :",max_key)
	res = dict(sorted(BC.items(), key = itemgetter(1), reverse = True)[:10]) 
  	# printing result 
	print("The top 10 Node centrality pairs are  " + str(res)) 
	#print(BC) 

	
	# Plot the centrality distribution
	all_centrality=DC.values()
	unique_centrality_1=list(set(all_centrality))
	#print unique_degrees
	count_of_centralities_1=[]
	for i in unique_centrality_1:
		x=list(all_centrality).count(i)
		count_of_centralities_1.append(x)

	all_centrality=EC.values()
	unique_centrality_2=list(set(all_centrality))
	#print unique_degrees
	count_of_centralities_2=[]
	for i in unique_centrality_2:
		x=list(all_centrality).count(i)
		count_of_centralities_2.append(x)


	all_centrality=CC.values()
	unique_centrality_3=list(set(all_centrality))
	#print unique_degrees
	count_of_centralities_3=[]
	for i in unique_centrality_3:
		x=list(all_centrality).count(i)
		count_of_centralities_3.append(x)


	all_centrality=BC.values()
	unique_centrality_4=list(set(all_centrality))
	#print unique_degrees
	count_of_centralities_4=[]
	for i in unique_centrality_4:
		x=list(all_centrality).count(i)
		count_of_centralities_4.append(x)

	plt.subplot(4, 1, 1)
	plt.plot(unique_centrality_1,count_of_centralities_1,'yo')
	plt.xlabel('Degree centralities')
	plt.ylabel('No of Nodes')
	plt.title('Degree centrality Distribution of Twitter network')
	#plt.title('Degree centrality Distribution of Arxiv HEP-TH collaboration network')
	#plt.title('Degree centrality Distribution of Gnutella peer-to-peer network')
	plt.tight_layout()

	plt.subplot(4, 1, 2)
	plt.plot(unique_centrality_2,count_of_centralities_2,'yo')
	plt.xlabel('Eigenvector centralities')
	plt.ylabel('No of Nodes')
	plt.title('Eigenvector centrality Distribution of Twitter network')
	#plt.title('Eigenvector centrality Distribution of Arxiv HEP-TH collaboration network')
	#plt.title('Eigenvector centrality Distribution of Gnutella peer-to-peer network')
	plt.tight_layout()

	plt.subplot(4, 1, 3)
	plt.plot(unique_centrality_3,count_of_centralities_3,'yo')
	plt.xlabel('Closeness centralities')
	plt.ylabel('No of Nodes')
	plt.title('Closeness centrality Distribution of Twitter network')
	#plt.title('Closeness centrality Distribution of Arxiv HEP-TH collaboration network')
	#plt.title('Closeness centrality Distribution of Gnutella peer-to-peer network')
	plt.tight_layout()

	plt.subplot(4, 1, 4)
	plt.plot(unique_centrality_4,count_of_centralities_4,'yo')
	plt.xlabel('Betweenness centralities')
	plt.ylabel('No of Nodes')
	plt.title('Betweenness centrality Distribution of Twitter network')
	#plt.title('Betweenness centrality Distribution of Arxiv HEP-TH collaboration network')
	#plt.title('Betweenness centrality Distribution of Gnutella peer-to-peer network')
	plt.tight_layout()
	plt.show()


print("facebook")
G=nx.read_edgelist('Data_sets/facebook_combined.txt')
centrality(G)
print("arxiv")
G=nx.read_edgelist('Data_sets/ca-HepTh.txt')
centrality(G)
print("gnutella")
G=nx.read_edgelist('Data_sets/p2p-Gnutella06.txt')
centrality(G)
print('Twitter')
G=nx.read_edgelist('Data_sets/twitter_combined.txt')
centrality(G)

