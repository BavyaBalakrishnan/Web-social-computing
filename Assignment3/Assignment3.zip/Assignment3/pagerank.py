import networkx as nx 
import matplotlib.pyplot as plt
from operator import itemgetter
#Return the PageRank of the nodes in the graph. 
def pagerank(G, alpha=0.85, personalization=None, 
			max_iteration=100, tolerance=1.0e-6, start_value=None, weight='weight', 
			dangling=None): 
	
    	"""
    	Parameters 
    	---------- 
    	G : graph 
      		A NetworkX graph.  Undirected graphs will be converted to a directed 
      		graph with two directed edges for each undirected edge. 
  
    	alpha : float, optional 
      		Damping parameter for PageRank, default=0.85. 
  
    	personalization: dict, optional 
      		By default, a uniform distribution is used. 
  
    	max_iteration : integer, optional 
      		Maximum number of iterations in power method eigenvalue solver. 
  
    	tolerance : float, optional 
      		Error tolerance used to check convergence in power method solver. 
  
    	start_value : dictionary, optional 
      		Starting value of PageRank iteration for each node. 
  
    	weight : key, optional 
      		Edge data key to use as weight.  If None weights are set to 1. 
  
    	dangling: dict, optional 
      		The outedges to be assigned to any "dangling" nodes, i.e., nodes without 
      		any outedges. The dict key :node the outedge points 
      		dict value: weight of that outedge. By default this is uniform if not 
      		specified. We can give same value for dangling dict and personalization dict. 
  
    	Returns 
    	------- 
    		pagerank : dictionary 
    		Dictionary of nodes with PageRank as value 
    """
	
	if len(G) == 0: 
		return {} 

	if not G.is_directed(): 
		D = G.to_directed() 
	else: 
		D = G 

	# Create a copy in (right) stochastic form 
	W = nx.stochastic_graph(D, weight=weight) 
	N = W.number_of_nodes() 

	# Choose default starting vector if no start_value is given 
	if start_value is None: 
		x = dict.fromkeys(W, 1.0 / N) 
	else: 
		# Normalized start_value vector 
		s = float(sum(start_value.values())) 
		x = dict((k, v / s) for k, v in start_value.items()) 

	if personalization is None: 

		# Assign uniform personalization vector if not specified 
		p = dict.fromkeys(W, 1.0 / N) 
	else: 
		missing = set(G) - set(personalization) 
		if missing: 
			raise NetworkXError('Personalization dictionary '
								'must have a value for every node. '
								'Missing nodes %s' % missing) 
		s = float(sum(personalization.values())) 
		p = dict((k, v / s) for k, v in personalization.items()) 

	if dangling is None: 

		# Use personalization vector if dangling vector not specifically given 
		dangling_weights = p 
	else: 
		missing = set(G) - set(dangling) 
		if missing: 
			raise NetworkXError('Dangling node dictionary '
								'must have a value for every node. '
								'Missing nodes %s' % missing) 
		s = float(sum(dangling.values())) 
		dangling_weights = dict((k, v/s) for k, v in dangling.items()) 
	dangling_nodes = [n for n in W if W.out_degree(n, weight=weight) == 0.0] 

	# power iteration: make up to max_iteration iterations 
	for _ in range(max_iteration): 
		xlast = x 
		x = dict.fromkeys(xlast.keys(), 0) 
		danglesum = alpha * sum(xlast[n] for n in dangling_nodes) 
		for n in x: 

			# this matrix multiply looks odd because it is 
			# doing a left multiply x^T=xlast^T*W 
			for nbr in W[n]: 
				x[nbr] += alpha * xlast[n] * W[n][nbr][weight] 
			x[n] += danglesum * dangling_weights[n] + (1.0 - alpha) * p[n] 

		# check convergence, l1 norm 
		err = sum([abs(x[n] - xlast[n]) for n in x]) 
		if err < N*tolerance: 
			return x 
	raise NetworkXError('pagerank: power iteration failed to converge '
						'in %d iterations.' % max_iteration) 


def rankdetails(pr):
	#Nodes having the highest and lowest PageRank
	all_values=pr.values()
	min_value=min(all_values)
	min_key=min(pr,key=pr.get)
	max_value=max(all_values)
	max_key=max(pr,key=pr.get)
	print("Page rank: Maximum value :",max_value)
	print("Page rank: Node with Maximum value :",max_key)
	print("Page rank: Minimum value :",min_value)
	print("Page rank: Node with Minimum value :",min_key)
	res = dict(sorted(pr.items(), key = itemgetter(1), reverse = True)[:10]) 
	# printing result 
	print("The top 10 Node ,Page rank pairs are  " + str(res)) 
	res = dict(sorted(pr.items(), key = itemgetter(1), reverse = False)[:10]) 
	# printing result 
	print("The Bottom 10 Node ,Page rank pairs are  " + str(res)) 


def plotRank(pr):
	all_ranks=pr.values()
	unique_ranks=list(set(all_ranks))
	#print unique_degrees
	count_of_ranks=[]
	for i in unique_ranks:
		x=list(all_ranks).count(i)
		count_of_ranks.append(x)

	plt.plot(unique_ranks,count_of_ranks,'yo')
	plt.xlabel('Page ranks')
	plt.ylabel('No of Nodes')
	plt.title('Rank Distribution of Twitter network')
	plt.show()


#G=nx.barabasi_albert_graph(60,41) 
print("Facebook")
G=nx.read_edgelist('Data_sets/facebook_combined.txt')
pr=pagerank(G,0.7) 
rankdetails(pr)
file1 = open("result.txt","w")
file1.write(str(pr))
#plt.bar(list(pr.keys()), pr.values(), color='g')
#plt.show()
#plotRank(pr)


print("Arxiv")
G=nx.read_edgelist('Data_sets/ca-HepTh.txt')
pr=pagerank(G,0.7) 
rankdetails(pr)
file2 = open("result1.txt","w")
file2.write(str(pr))
#plt.bar(list(pr.keys()), pr.values(), color='g')
#plt.show()
#plotRank(pr)


print("Gnutella")
G=nx.read_edgelist('Data_sets/p2p-Gnutella06.txt')
pr=pagerank(G,0.7) 
rankdetails(pr)
file3 = open("result2.txt","w")
file3.write(str(pr))
#plt.bar(list(pr.keys()), pr.values(), color='g')
#plt.show()
#plotRank(pr)

print("Twitter")
G=nx.read_edgelist('Data_sets/twitter_combined.txt')
pr=pagerank(G,0.7) 
rankdetails(pr)
file4 = open("result3.txt","w")
file4.write(str(pr))
#plt.bar(list(pr.keys()), pr.values(), color='g')
#plt.show()
plotRank(pr)

file1.close()   
file2.close()
file3.close()
file4.close()
